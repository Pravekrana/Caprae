# Architecture and engineering decisions

LeadBench is a single-workspace prototype with two feature boundaries: reconciliation of company records and explainable acquisition-fit review. The system is deliberately small enough to run and inspect within the handbook's five-hour engineering limit.

```mermaid
flowchart LR
    CSV[CSV exports from sourcing workflows] --> UI[Browser review interface]
    UI -->|JSON over same origin| API[Python HTTP application]
    API --> V[Input validation and reconciliation]
    API --> R[Buy-box scoring rules]
    V --> DB[(SQLite with WAL)]
    R --> DB
    DB --> API
    API --> UI
    UI --> OUT[Reviewed CSV for CRM import]
```

## API boundaries

| Route | Responsibility |
| --- | --- |
| GET /api/health | Liveness check |
| GET /api/settings | Saved acquisition criteria |
| POST /api/settings | Validate and save criteria; subsequent reads recalculate scores |
| GET /api/leads | Company records, factor explanations, tiers, and queue summary; optional search/status/tier filters |
| POST /api/import | Validate CSV, normalize fields, reconcile identities and preserve source conflicts |
| POST /api/leads/status | Persist selected review states |
| GET /demo_leads.csv | Distributable synthetic demonstration fixture |

JSON mutation responses are sent after the transaction commits. Imports acquire a SQLite write lock before duplicate lookup, so concurrent ingestion cannot independently classify the same new company and insert it twice. Connections close after each session. Request and import bounds keep this prototype's synchronous work finite; they are not a production capacity guarantee.

## Storage decisions

Company rows hold the canonical profile, review status, timestamps, and a normalized identity key. The saved buy box is JSON in a settings table. Indexes support domain, normalized company name, and status lookups. SQLite avoids infrastructure dependencies, provides transactions, and fits a private workspace that needs durable local state. WAL permits readers during a writer's activity, while writes remain serialized.

The first non-empty value is retained when observations disagree; conflicting values and provenance are appended to the evidence trail. This makes a disputed value inspectable, rather than silently replacing it. Source presence and verification are separate concepts: a named source earns provenance points, but does not validate the claim. Domain presence is likewise an imported identity signal, without a DNS or ownership check.

The evidence trail is text in this time-boxed version. A production design should store immutable observations in a separate table with source identifiers, observed timestamps, field-level values, and reconciliation decisions. That would support structured provenance, explicit conflict resolution, suppression rules, retention, and auditing without parsing a note field.

## Identity assumptions

A shared normalized website domain is treated as one company. This assumption needs human review for franchises, subsidiaries, shared corporate websites, and multi-brand groups. Domainless records require matching normalized names and explicit locations; absent identifiers are kept separate. This favors missed merges over confidently combining unrelated records, but no heuristic eliminates false matches. A production workflow should expose a merge review queue and reversible merge decisions.

## Scoring and UX

Rules produce visible factor points. Industry, revenue, and geography are core requirements for the Priority tier, so a high weighted score cannot override a known core mismatch. Missing core data remains a review task. Employee size, declared domain, and source trail add context; they do not establish verified financials, deliverability, or owner intent.

The browser keeps import, search, filters, inspection, shortlisting, and export in one workspace. Detail explanations avoid a hidden recommendation that a searcher cannot challenge. Selected export counts are explicit; an unselected export follows the current filter. Empty states, a responsive layout, and offline font fallbacks keep the workflow usable when data or network access is limited.

## Performance and caching

Scores are inexpensive and recalculated on reads; the JSON API sends `Cache-Control: no-store`. No external API cache or LLM cache exists. Exact domain and identity indexes avoid repeated full scans in common ingestion paths. The browser currently loads the workspace list, which is suitable for the bounded prototype. Pagination, background ingestion jobs, server-side filtering, and representative load tests precede a larger dataset rollout.

## Hosting boundary

The application serves static files and JSON locally. There is no serverless deployment, public URL, or provisioned cloud resource. The concrete proposed private-pilot path is AWS EC2 with encrypted EBS for SQLite, Nginx for TLS and asset delivery, and a managed process with a non-login service account. The README contains the deployment sequence.

Production access requires authenticated sessions, authorization, retention decisions, backups with tested restore, operational monitoring, and an appropriate application server. Scale-out requires a managed database such as PostgreSQL on AWS RDS and a shared identity/tenant model. API keys and customer data must not enter the repository. These are future operating requirements, not features claimed by this submission.
