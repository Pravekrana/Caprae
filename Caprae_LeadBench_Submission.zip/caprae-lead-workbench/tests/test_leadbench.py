import csv
import io
import os
import tempfile
import threading
import unittest
import sys
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import server as app


class LeadBenchTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = Path(self.tmp.name) / "test.sqlite3"
        app.init_db(self.db_path)

    def tearDown(self):
        self.tmp.cleanup()

    def db(self):
        return app.connect(self.db_path)

    def test_empty_industry_and_location_never_match(self):
        lead = {"company":"No profile", "industry":"", "location":"", "revenue":None, "employees":None, "domain":"", "source":"", "source_url":""}
        score = app.score_lead(lead, {"industries":[""],"locations":[""],"revenue_min":None,"revenue_max":None,"employee_min":None,"employee_max":None})
        self.assertEqual(score["score"], 0)
        self.assertEqual(score["factors"][0]["points"], 0)
        self.assertEqual(score["factors"][2]["points"], 0)

    def test_geography_uses_whole_tokens_and_country_aliases(self):
        self.assertTrue(app.location_matches("Denver CO USA", ["United States"]))
        self.assertTrue(app.location_matches("Remote US", ["USA"]))
        self.assertFalse(app.location_matches("Sydney Australia", ["US"]))
        self.assertFalse(app.location_matches("Austin TX USA", [""]))

    def test_numeric_parser_rejects_nonfinite_negative_and_fractional_headcount(self):
        self.assertIsNone(app.parse_number("nan"))
        self.assertIsNone(app.parse_number("inf"))
        self.assertIsNone(app.parse_number("-50"))
        self.assertIsNone(app.parse_number("3.5", integer=True))
        self.assertEqual(app.parse_number("2,500", integer=True), 2500)

    def test_domain_normalization_and_same_name_distinct_domain(self):
        self.assertEqual(app.normalize_domain("https://www.example.com/profile"), "example.com")
        text = "Company,Domain,Location\nAcme,acme-one.example,US\nAcme,acme-two.example,US\n"
        with app.session(self.db_path) as db:
            result = app.import_csv(db, text)
            self.assertEqual(result["inserted"], 2)
            self.assertEqual(result["merged"], 0)
        self.assertTrue(app.norm("株式会社山田"))

    def test_identical_demo_reimport_does_not_grow_provenance(self):
        fixture = (Path(__file__).resolve().parents[1] / "data" / "demo_leads.csv").read_text(encoding="utf-8")
        with app.session(self.db_path) as db:
            first = app.import_csv(db, fixture)
            evidence_before = db.execute("SELECT evidence FROM leads WHERE company='Northstar IT'").fetchone()[0]
            second = app.import_csv(db, fixture)
            evidence_after = db.execute("SELECT evidence FROM leads WHERE company='Northstar IT'").fetchone()[0]
            self.assertEqual(first["inserted"], 11)
            self.assertEqual(second["merged"], 12)
            self.assertEqual(evidence_before, evidence_after)

    def test_duplicate_merge_preserves_second_source_and_conflict(self):
        first = "Company,Domain,Revenue,Source,Source URL,Evidence\nAcme,acme.example,1000000,Directory,https://one.example,Revenue estimate\n"
        second = "Company,Domain,Revenue,Source,Source URL,Evidence\nAcme,https://acme.example,1200000,Trade group,https://two.example,Confirmed headcount\n"
        with app.session(self.db_path) as db:
            self.assertEqual(app.import_csv(db, first)["inserted"], 1)
            self.assertEqual(app.import_csv(db, second)["merged"], 1)
            row = db.execute("SELECT * FROM leads").fetchone()
            self.assertIn("source=Trade group", row["evidence"])
            self.assertIn("source_url=https://two.example", row["evidence"])
            self.assertIn("Conflict (revenue)", row["evidence"])
            self.assertEqual(row["revenue"], 1000000)

    def test_duplicate_import_is_idempotent(self):
        text = "Company,Domain,Source,Source URL\nAcme,acme.example,Directory,https://one.example\n"
        with app.session(self.db_path) as db:
            app.import_csv(db, text)
            result = app.import_csv(db, text)
            self.assertEqual(result["merged"], 1)
            row = db.execute("SELECT evidence FROM leads").fetchone()
            self.assertEqual(row[0].count("Imported observation"), 0)

    def test_import_bounds_and_missing_company_header(self):
        with app.session(self.db_path) as db:
            too_many = "Company,Domain\n" + "".join(f"Company {i},company-{i}.example\n" for i in range(2001))
            with self.assertRaises(ValueError): app.import_csv(db, too_many)
            with self.assertRaises(ValueError): app.import_csv(db, "Name of founder\nCasey\n")
            with self.assertRaises(ValueError): app.import_csv(db, "Company\n" + ("A" * 2_000_001))

    def test_missing_source_note_does_not_count_as_source_evidence(self):
        lead = {"company":"Unknown", "industry":"B2B SaaS", "location":"United States", "revenue":5_000_000, "employees":50, "domain":"unknown.example", "source":"", "source_url":"", "evidence":"No proof available"}
        score = app.score_lead(lead, app.DEFAULT_BUYBOX)
        self.assertEqual(score["factors"][-1]["points"], 0)

    def test_http_settings_validation_and_static_path_guard(self):
        old = app.DB_PATH
        app.DB_PATH = self.db_path
        http = ThreadingHTTPServer(("127.0.0.1", 0), app.Handler)
        thread = threading.Thread(target=http.serve_forever, daemon=True); thread.start()
        base = f"http://127.0.0.1:{http.server_port}"
        try:
            with urlopen(base + "/api/health") as resp: self.assertIn(b'"ok": true', resp.read())
            imported = Request(base + "/api/import", data=b'{"csv":"Company,Domain,Industry,Location,Revenue,Employees,Source\\nNorthstar,northstar.example,IT Services,Denver CO USA,8000000,60,Fixture directory\\n"}', headers={"Content-Type":"application/json"}, method="POST")
            with urlopen(imported) as resp: self.assertEqual(resp.status, 201)
            update = Request(base + "/api/leads/status", data=b'{"ids":[1],"status":"shortlist"}', headers={"Content-Type":"application/json"}, method="POST")
            with urlopen(update) as resp: self.assertIn(b'"updated": 1', resp.read())
            with urlopen(base + "/api/leads") as resp:
                payload = __import__("json").loads(resp.read())
                self.assertEqual(payload["leads"][0]["status"], "shortlist")
                self.assertEqual(payload["leads"][0]["tier"], "Priority")
            saved = Request(base + "/api/settings", data=b'{"industries":["IT Services"],"locations":["US"],"revenue_min":100,"revenue_max":10000000,"employee_min":1,"employee_max":100}', headers={"Content-Type":"application/json"}, method="POST")
            with urlopen(saved) as resp: self.assertIn(b'IT Services', resp.read())
            text_request = Request(base + "/api/import", data=b'{}', headers={"Content-Type":"text/plain"}, method="POST")
            with self.assertRaises(HTTPError) as err: urlopen(text_request)
            self.assertEqual(err.exception.code, 415)
            origin_request = Request(base + "/api/import", data=b'{"csv":"Company\\n"}', headers={"Content-Type":"application/json", "Origin":"http://attacker.example"}, method="POST")
            with self.assertRaises(HTTPError) as err: urlopen(origin_request)
            self.assertEqual(err.exception.code, 403)
            data = b'{"revenue_min":500,"revenue_max":20,"employee_min":1,"employee_max":5,"industries":[],"locations":[]}'
            req = Request(base + "/api/settings", data=data, headers={"Content-Type":"application/json"}, method="POST")
            with self.assertRaises(HTTPError) as err: urlopen(req)
            self.assertEqual(err.exception.code, 400)
            with self.assertRaises(HTTPError): urlopen(base + "/..%2fserver.py")
            with urlopen(base + "/demo_leads.csv") as resp: self.assertIn(b"Northstar IT", resp.read())
        finally:
            http.shutdown(); http.server_close(); thread.join(timeout=2); app.DB_PATH = old


if __name__ == "__main__":
    unittest.main(verbosity=2)
