# LeadBench walkthrough

Target length: 90 seconds. The screen recording uses the synthetic fixture only. Captions are written to work naturally as a silent walkthrough.

| Time | Screen action | Caption |
|---|---|---|
| 0:00–0:10 | Open the populated lead review dashboard. | LeadBench helps an acquisition team decide what to verify before spending time on enrichment. |
| 0:10–0:24 | Open Import leads, choose Use demo CSV, import. | The fixture has twelve synthetic rows, including an intentional duplicate. Import normalizes the domain and merges the repeated company while preserving its second source observation. |
| 0:24–0:39 | Search for Northstar IT and open its detail drawer. | Every score factor is visible: industry, revenue, geography, employee range, company identity, and source trail. The score uses deterministic rules, not a model call. |
| 0:39–0:53 | Open Clearwater HVAC, inspect gaps, then close. | Missing data and missing source provenance stay visible. A note that says “no proof” is not treated as a source. |
| 0:53–1:07 | Filter to Priority, select a lead, set status to Shortlist. | Priority requires an explicit match on the core industry, revenue, and geography criteria. Missing core inputs need review; known mismatches move to low fit. |
| 1:07–1:20 | Open Buy box, adjust one criterion, save; show scores update. | The team can change its buy box and see the explanation recalculate immediately. |
| 1:20–1:30 | Export selected CSV and end on dashboard. | Export the reviewed subset to a CRM workflow. This prototype uses fictional data and does not scrape, verify contacts, or make investment decisions. |

Suggested closing card: **LeadBench — review the evidence before the next enrichment step.**
