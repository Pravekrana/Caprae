# LeadBench

LeadBench is a small deal-sourcing review desk that helps an acquisition team decide what to verify or enrich next. It imports a CSV, merges likely duplicate company records while retaining source observations, scores each company against an editable buy box, explains every score factor, supports shortlist/status actions, and exports selected or filtered rows for a CRM workflow.

The working hypothesis is that making fit and evidence gaps inspectable before enrichment can reduce wasted research effort. SaaSquatch Leads already presents lead search, enrichment, company insights, revenue estimates, and CSV/Excel export on its public product pages. LeadBench is a five-hour prototype exploring a complementary review step, not a replacement claim. The reference also says users can choose which leads to enrich. See [SaaSquatch Leads](https://www.saasquatchleads.com/), [Company Insights](https://www.saasquatchleads.com/products/company-insights), and [Enrichment](https://www.saasquatchleads.com/products/enrichment). Caprae's public [Search as a Service overview](https://capraecapital.com/services/) describes buy-box-based off-market sourcing and owner outreach, which informs the acquisition criteria and next-action language here.

## Run the demo

The app uses only Python 3.10 or newer standard library modules and does not need a package install.

On Windows PowerShell:

```powershell
.\launch.ps1
```

On macOS, Linux, or Windows with Python on `PATH`:

```sh
python3 server.py
```

Open [http://127.0.0.1:8765](http://127.0.0.1:8765). The first run creates `data/leads.sqlite3`. To use another port or database file, set `PORT` or `LEAD_DB_PATH` before starting. The PowerShell launcher checks `LEADBENCH_PYTHON`, common Python commands, then the current user's bundled Codex Python runtime when present.

Choose **Import leads → Use demo CSV** to load the included synthetic fixture. It contains 12 CSV rows, including one intentional duplicate, yielding 11 distinct companies. All names, domains, people, contact details, and evidence in `data/demo_leads.csv` are fictional `.example` fixtures. They are not real prospects and must not be used for outreach.

## What the prototype does

- Imports CSV with flexible header matching, normalizes domains and common numeric fields, and rejects files over 2 MB or 2,000 data rows.
- Matches duplicates by normalized domain first, then by company name and exact non-empty location when one record lacks a domain. It does not merge same-name records with distinct known domains or guess when both location and domain are absent.
- Fills blank fields from a duplicate observation, keeps the first reviewed value on conflicts, and appends the second source URL, source name, note, and any conflicting values to the evidence trail. Reimporting an identical observation is idempotent.
- Assigns a deterministic 0–100 fit score: industry (30), revenue (25), geography (15), employee range (10), company identity (10), and source trail (10). Every factor has a plain-language reason in the detail view.
- Requires industry, revenue, and geography to match the buy box before a lead can enter **Priority**. Missing core fields remain **Review**; known core mismatches become **Low fit**. The score is a triage aid, not an investment recommendation or a claim of verified business quality.
- Filters and searches records; updates status to new, shortlist, contacted, or archived; exports selected companies or the current filtered list as CSV. Exported spreadsheet formula-like values receive a leading apostrophe to reduce formula injection risk.

The app never scrapes websites, contacts people, calls a third-party enrichment API, verifies email or phone details, or makes a deal decision. A source trail records where a row came from; it does not establish that its claims are true.

## Architecture

| Layer | Implementation |
|---|---|
| Browser UI | Semantic HTML, responsive CSS, and plain JavaScript; no frontend build step or framework |
| HTTP application | Python 3 standard library `ThreadingHTTPServer`, JSON routes, and static asset serving |
| Storage | SQLite database with WAL mode and indexes for domain, company, and status; one local workspace database |
| Scoring | Deterministic Python rules evaluated on read against the saved buy box; no model calls or hidden score cache |
| CSV | Python `csv` module for import; browser-generated CSV for selected/filter results |
| Runtime cache | No application cache. The database uses indexed exact-domain and normalized-company lookups; a domainless company with no location is kept as a separate ambiguous record rather than scanned or merged. Imports are deliberately bounded. |

The read path recomputes scores so saved buy-box changes apply immediately without invalidation logic. CSV ingestion validates fields, uses an indexed normalized company key, and serializes identity-check-plus-insert inside a SQLite write transaction. SQLite WAL lets readers proceed while a writer is active, but this remains a single-workspace prototype: there is no tenant model, login, CRM synchronization, background job queue, contact verification, or concurrency/load guarantee.

## Deployment design

Nothing in this repository is deployed or hosted. For a small private pilot, the proposed hosting target is one AWS EC2 instance with an encrypted persistent EBS volume holding the SQLite database. Run the Python process under `systemd` bound to loopback; put Nginx in front for TLS termination, request limits, static asset delivery, and reverse proxying. Keep backups outside the instance and test restore before use. This is a concrete low-operations path compatible with a persistent SQLite file; a serverless container with ephemeral disk would lose this prototype's database on replacement.

Before exposing the pilot beyond a trusted team, add company SSO, authenticated sessions, tenant isolation, role-based access, audit logging, TLS-only access, secrets management, and a data retention policy. The current origin check is a local demo safeguard, not authentication or a production security boundary. Back up the EBS volume and SQLite database on a schedule, monitor free disk space and service health, and document recovery steps. If concurrent writers or multi-tenant use become product requirements, migrate persistence to managed PostgreSQL (for example, AWS RDS) before horizontal app scaling.

Deployment sequence: provision the EC2 host and encrypted EBS volume; install a supported Python 3 runtime and Nginx; clone the repository to a locked-down service directory; create a non-login service user; mount EBS at a stable database path; configure `LEAD_DB_PATH`, `HOST=127.0.0.1`, and `PORT`; install a `systemd` unit; configure Nginx TLS and reverse proxy rules; enable SSO and restrict access; configure off-instance backups and health monitoring; then deploy updates through a reviewed commit and service restart with a backup captured first. These are recommendations only; no cloud resources or external services were changed by this assessment.

## Verification

Run the focused backend suite with:

```powershell
& 'C:\path\to\python.exe' -m unittest discover -s tests -v
```

The suite covers score edge cases, geography token matching, numeric parsing, duplicate identity and source retention, idempotent imports, CSV bounds, API persistence/validation, cross-origin request rejection, and static path traversal. Browser interaction and responsive layout were also reviewed in the assessment walkthrough. An isolated synthetic import benchmark on the bundled local Python runtime processed 1,000 companies with distinct domains in 0.57 seconds after avoiding a full-table duplicate scan on domain misses; this is a local smoke measurement, not a production capacity claim.

## Walkthrough

See [`WALKTHROUGH.md`](WALKTHROUGH.md) for the 90-second screen demonstration outline and caption copy. The fixture CSV is intentionally included for reproducibility; no third-party or customer data is bundled.

## Review material

See [architecture decisions](docs/ARCHITECTURE.md) for the system diagram, API boundaries, identity assumptions, and production path. See [validation evidence](docs/VALIDATION.md) for the final test results and reproducible review checklist.
