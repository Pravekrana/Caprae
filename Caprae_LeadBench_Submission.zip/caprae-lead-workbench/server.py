"""LeadBench: a small, explainable pre-enrichment lead triage service.

Uses only Python's standard library so the demo runs without a package install.
"""
from __future__ import annotations

import csv
import io
import json
import os
import re
import sqlite3
import math
import unicodedata
from datetime import datetime, timezone
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("LEAD_DB_PATH", ROOT / "data" / "leads.sqlite3"))
DEFAULT_BUYBOX = {
    "industries": ["B2B SaaS", "IT Services", "Business Services"],
    "locations": ["United States", "US", "USA"],
    "revenue_min": 1_000_000,
    "revenue_max": 25_000_000,
    "employee_min": 10,
    "employee_max": 200,
}


def connect(db_path: Path | None = None) -> sqlite3.Connection:
    db_path = Path(db_path or DB_PATH)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


@contextmanager
def session(db_path: Path | None = None):
    db = connect(db_path)
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def init_db(db_path: Path | None = None) -> None:
    with session(db_path) as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS leads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company TEXT NOT NULL,
            company_key TEXT NOT NULL DEFAULT '',
            domain TEXT NOT NULL DEFAULT '',
            industry TEXT NOT NULL DEFAULT '',
            location TEXT NOT NULL DEFAULT '',
            revenue REAL,
            employees INTEGER,
            owner TEXT NOT NULL DEFAULT '',
            email TEXT NOT NULL DEFAULT '',
            phone TEXT NOT NULL DEFAULT '',
            source TEXT NOT NULL DEFAULT '',
            source_url TEXT NOT NULL DEFAULT '',
            evidence TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'new',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_leads_company ON leads(company);
        CREATE INDEX IF NOT EXISTS idx_leads_domain ON leads(domain);
        CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);
        """)
        columns = {row[1] for row in db.execute("PRAGMA table_info(leads)")}
        if "company_key" not in columns:
            db.execute("ALTER TABLE leads ADD COLUMN company_key TEXT NOT NULL DEFAULT ''")
        db.execute("CREATE INDEX IF NOT EXISTS idx_leads_company_key ON leads(company_key)")
        for row in db.execute("SELECT id,company FROM leads WHERE company_key='' ").fetchall():
            db.execute("UPDATE leads SET company_key=? WHERE id=?", (norm(row["company"]), row["id"]))
        if not db.execute("SELECT 1 FROM settings WHERE key='buybox'").fetchone():
            db.execute("INSERT INTO settings(key,value) VALUES('buybox',?)", (json.dumps(DEFAULT_BUYBOX),))


def clean(value: object) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def norm(value: str) -> str:
    value = unicodedata.normalize("NFKC", clean(value)).casefold()
    return "".join(char for char in value if char.isalnum())


def normalize_domain(value: str) -> str:
    value = clean(value).lower()
    value = re.sub(r"^https?://", "", value)
    value = value.split("/")[0].split("?")[0].split("#")[0]
    return value.removeprefix("www.").strip(" .")


def parse_number(value: str, integer: bool = False):
    value = clean(value).replace(",", "").replace("$", "")
    if not value:
        return None
    try:
        num = float(value)
        if not math.isfinite(num) or num < 0 or (integer and not num.is_integer()):
            return None
        return int(num) if integer else num
    except (ValueError, OverflowError):
        return None


def location_matches(actual: str, targets: list[str]) -> bool:
    """Match whole location tokens; normalize common US country spellings."""
    aliases = {"us", "usa", "united states", "united states of america"}
    actual_words = set(re.findall(r"[a-z]+", clean(actual).lower()))
    actual_text = " ".join(re.findall(r"[a-z]+", clean(actual).lower()))
    actual_is_us = bool(actual_words & {"us", "usa"}) or "united states" in actual_text
    for target in targets:
        target_words = re.findall(r"[a-z]+", clean(target).lower())
        target_text = " ".join(target_words)
        if not target_words:
            continue
        if target_text in aliases and actual_is_us:
            return True
        if target_text not in aliases and all(word in actual_words for word in target_words):
            return True
    return False


def score_lead(lead: dict, buybox: dict) -> dict:
    """Deterministic rules, returned with per-factor evidence for every score."""
    factors = []
    def add(name, points, maximum, reason):
        factors.append({"name": name, "points": points, "maximum": maximum, "reason": reason})

    industries = [norm(x) for x in buybox.get("industries", []) if norm(x)]
    industry = norm(lead.get("industry", ""))
    exact = bool(industry) and any(industry == i or i in industry or industry in i for i in industries)
    add("Industry fit", 30 if exact else 0, 30,
        f"{lead.get('industry') or 'Industry missing'} {'matches a buy-box target' if exact else 'does not match a buy-box target'}.")

    revenue = lead.get("revenue")
    rmin, rmax = buybox.get("revenue_min"), buybox.get("revenue_max")
    rev_ok = revenue is not None and (rmin is None or revenue >= rmin) and (rmax is None or revenue <= rmax)
    add("Revenue fit", 25 if rev_ok else 0, 25,
        f"{money(revenue)} {'is inside' if rev_ok else 'is outside or missing from'} the configured revenue range.")

    locations = buybox.get("locations", [])
    loc_ok = bool(clean(lead.get("location", ""))) and location_matches(lead.get("location", ""), locations)
    add("Geography fit", 15 if loc_ok else 0, 15,
        f"{lead.get('location') or 'Location missing'} {'matches' if loc_ok else 'does not match'} a target geography.")

    emin, emax = buybox.get("employee_min"), buybox.get("employee_max")
    employees = lead.get("employees")
    emp_ok = employees is not None and (emin is None or employees >= emin) and (emax is None or employees <= emax)
    add("Company size", 10 if emp_ok else 0, 10,
        f"{employees if employees is not None else 'Employee count missing'} {'is inside' if emp_ok else 'is outside or missing from'} the configured employee range.")

    has_domain = bool(lead.get("domain"))
    add("Identity evidence", 10 if has_domain else 0, 10,
        f"{lead.get('domain') or 'No domain supplied'} {'provides' if has_domain else 'does not provide'} a stable company identifier.")
    # Notes alone are not provenance: require a named source or retrievable URL.
    has_source = bool(lead.get("source") or lead.get("source_url"))
    add("Source evidence", 10 if has_source else 0, 10,
        "A named source or source URL is recorded." if has_source else "No named source or source URL is recorded.")
    return {"score": sum(f["points"] for f in factors), "factors": factors}


def money(value):
    if value is None: return "Revenue missing"
    return "$" + format(value, ",.0f")


def load_buybox(db: sqlite3.Connection) -> dict:
    row = db.execute("SELECT value FROM settings WHERE key='buybox'").fetchone()
    return json.loads(row[0]) if row else dict(DEFAULT_BUYBOX)


def serialize(row: sqlite3.Row, buybox: dict) -> dict:
    lead = dict(row)
    lead["revenue"] = float(lead["revenue"]) if lead["revenue"] is not None else None
    lead["employees"] = int(lead["employees"]) if lead["employees"] is not None else None
    scored = score_lead(lead, buybox)
    lead.update(scored)
    core = {factor["name"]: factor["points"] for factor in scored["factors"][:3]}
    core_values = (lead.get("industry"), lead.get("revenue"), lead.get("location"))
    core_names = ("Industry fit", "Revenue fit", "Geography fit")
    hard_mismatch = any(value not in (None, "") and core[name] == 0 for value, name in zip(core_values, core_names))
    core_missing = any(value in (None, "") for value in core_values)
    lead["tier"] = "Low fit" if hard_mismatch else "Priority" if lead["score"] >= 70 and not core_missing else "Review"
    return lead


def find_duplicate(db: sqlite3.Connection, company: str, domain: str, location: str):
    if domain:
        row = db.execute("SELECT * FROM leads WHERE lower(domain)=lower(?) AND domain<>'' LIMIT 1", (domain,)).fetchone()
        if row: return row
    target_name, target_location = norm(company), norm(location)
    if not target_name or (not domain and not target_location):
        return None
    rows = db.execute("SELECT * FROM leads WHERE company_key=? ORDER BY id", (target_name,)).fetchall()
    for row in rows:
        # Two distinct known domains are different entities even when names match.
        if domain and row["domain"] and domain.lower() != row["domain"].lower():
            continue
        if norm(row["company"]) == target_name and target_location and norm(row["location"]) == target_location:
            return row
    return None


def import_csv(db: sqlite3.Connection, text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("CSV content must be text.")
    if len(text.encode("utf-8")) > 2_000_000:
        raise ValueError("CSV must be smaller than 2 MB.")
    reader = csv.DictReader(io.StringIO(text.lstrip("\ufeff")))
    if not reader.fieldnames:
        raise ValueError("CSV needs a header row.")
    aliases = {
        "company": ["company", "company name", "business", "name"],
        "domain": ["domain", "website", "company website", "url"],
        "industry": ["industry", "sector", "vertical"],
        "location": ["location", "hq location", "city", "geography"],
        "revenue": ["revenue", "estimated revenue", "annual revenue"],
        "employees": ["employees", "employee count", "headcount"],
        "owner": ["owner", "contact", "contact name", "decision maker"],
        "email": ["email", "owner email", "contact email"],
        "phone": ["phone", "owner phone", "contact phone"],
        "source": ["source", "data source", "source name"],
        "source_url": ["source url", "source link", "profile url"],
        "evidence": ["evidence", "notes", "source notes"],
    }
    fields = {key: next((h for h in reader.fieldnames if clean(h).lower() in names), None) for key, names in aliases.items()}
    if not fields["company"]:
        raise ValueError("CSV needs a Company or Company Name column.")
    counts = {"inserted": 0, "merged": 0, "skipped": 0}
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    for row_number, source_row in enumerate(reader, start=2):
        if row_number > 2001:
            raise ValueError("CSV can contain at most 2,000 data rows.")
        item = {key: clean(source_row.get(header, "")) if header else "" for key, header in fields.items()}
        item["company"] = item["company"][:200]
        item["domain"] = normalize_domain(item["domain"])
        if not item["company"]:
            counts["skipped"] += 1; continue
        item["revenue"] = parse_number(item["revenue"])
        item["employees"] = parse_number(item["employees"], True)
        dupe = find_duplicate(db, item["company"], item["domain"], item["location"])
        if dupe:
            # Fill gaps while preserving values already reviewed; append provenance for auditability.
            updates = {}
            for key in ("domain", "industry", "location", "revenue", "employees", "owner", "email", "phone", "source", "source_url"):
                if not dupe[key] and item[key] not in (None, ""):
                    updates[key] = item[key]
            prior = dupe["evidence"]
            provenance_values = []
            evidence_parts = [part for part in prior.split(" | ") if part]
            for field, label in (("source", "source"), ("source_url", "source_url"), ("evidence", "evidence")):
                value = item[field]
                already_recorded = (field == "evidence" and value in evidence_parts) or (value and f"{label}={value}" in prior)
                if value and value != (dupe[field] or "") and not already_recorded:
                    provenance_values.append(f"{label}={value}")
            provenance = "Imported observation: " + "; ".join(provenance_values)
            if provenance != "Imported observation: " and provenance not in evidence_parts:
                evidence_parts.append(provenance)
            for key in ("industry", "location", "revenue", "employees", "owner", "email", "phone"):
                old = dupe[key]
                new = item[key]
                if old not in (None, "") and new not in (None, "") and str(old).lower() != str(new).lower():
                    conflict = f"Conflict ({key}): existing={old}; imported={new}"
                    if conflict not in evidence_parts:
                        evidence_parts.append(conflict)
            if evidence_parts and " | ".join(evidence_parts) != prior:
                updates["evidence"] = " | ".join(evidence_parts)
            updates["updated_at"] = now
            if updates:
                clause = ",".join(f"{key}=?" for key in updates)
                db.execute(f"UPDATE leads SET {clause} WHERE id=?", (*updates.values(), dupe["id"]))
            counts["merged"] += 1
        else:
            db.execute("""INSERT INTO leads(company,company_key,domain,industry,location,revenue,employees,owner,email,phone,source,source_url,evidence,created_at,updated_at)
                          VALUES(:company,:company_key,:domain,:industry,:location,:revenue,:employees,:owner,:email,:phone,:source,:source_url,:evidence,:now,:now)""", {**item, "company_key":norm(item["company"]), "now": now})
            counts["inserted"] += 1
    return counts


class Handler(BaseHTTPRequestHandler):
    server_version = "LeadBench/1.0"
    def log_message(self, fmt, *args):
        print(f"[{self.log_date_time_string()}] {fmt % args}")
    def send_json(self, value, status=200):
        body = json.dumps(value, ensure_ascii=False).encode()
        self.send_response(status); self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body))); self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(body)
    def body_json(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        if length > 2_100_000:
            raise ValueError("Request body is too large.")
        payload = json.loads(self.rfile.read(length) or b"{}")
        if not isinstance(payload, dict):
            raise ValueError("JSON body must be an object.")
        return payload
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path.startswith("/api/"):
            with session() as db:
                if parsed.path == "/api/health": return self.send_json({"ok": True})
                if parsed.path == "/api/settings": return self.send_json(load_buybox(db))
                if parsed.path == "/api/leads":
                    q = parse_qs(parsed.query); rows = db.execute("SELECT * FROM leads ORDER BY updated_at DESC,id DESC").fetchall()
                    buybox = load_buybox(db); leads = [serialize(r, buybox) for r in rows]
                    search = q.get("q", [""])[0].lower().strip()
                    status = q.get("status", [""])[0]
                    tier = q.get("tier", [""])[0]
                    if search: leads = [x for x in leads if search in " ".join(str(x.get(k, "")) for k in ("company","domain","industry","location","owner","email","source")).lower()]
                    if status: leads = [x for x in leads if x["status"] == status]
                    if tier: leads = [x for x in leads if x["tier"] == tier]
                    summary = {"total": len(rows), "priority": sum(x["tier"]=="Priority" for x in leads), "review": sum(x["tier"]=="Review" for x in leads), "low": sum(x["tier"]=="Low fit" for x in leads), "missing_source": sum(not (x["source"] or x["source_url"]) for x in leads)}
                    return self.send_json({"leads": leads, "summary": summary})
            return self.send_json({"error":"Not found"}, 404)
        static_root = (ROOT / "static").resolve()
        path = (static_root / ("index.html" if parsed.path in ("/", "") else parsed.path.lstrip("/"))).resolve()
        if path != static_root and static_root not in path.parents:
            return self.send_error(404)
        if parsed.path == "/demo_leads.csv":
            path = (ROOT / "data" / "demo_leads.csv").resolve()
        try:
            body = path.read_bytes()
        except (FileNotFoundError, IsADirectoryError): return self.send_error(404)
        content_type = "text/html; charset=utf-8" if path.suffix == ".html" else "text/css; charset=utf-8" if path.suffix == ".css" else "text/javascript; charset=utf-8" if path.suffix == ".js" else "application/octet-stream"
        self.send_response(200); self.send_header("Content-Type", content_type); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def do_POST(self):
        if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json":
            return self.send_json({"error":"Content-Type must be application/json."}, 415)
        origin = self.headers.get("Origin")
        if origin and urlparse(origin).netloc.lower() != self.headers.get("Host", "").lower():
            return self.send_json({"error":"Cross-origin requests are not accepted."}, 403)
        try:
            payload = self.body_json()
            with session() as db:
                if self.path == "/api/import":
                    # Serialize the identity check and insert as one write transaction.
                    db.execute("BEGIN IMMEDIATE")
                    result = import_csv(db, payload.get("csv", ""))
                    db.commit()
                    return self.send_json(result, 201)
                if self.path == "/api/leads/status":
                    ids, status = payload.get("ids", []), payload.get("status", "new")
                    if not isinstance(ids, list) or len(ids) > 2_000 or any(not isinstance(i, int) or isinstance(i, bool) or i <= 0 for i in ids): return self.send_json({"error":"IDs must be positive integers, up to 2,000."}, 400)
                    if status not in ("new", "shortlist", "contacted", "archived"): return self.send_json({"error":"Invalid status"}, 400)
                    if ids: db.executemany("UPDATE leads SET status=?,updated_at=? WHERE id=?", [(status, datetime.now(timezone.utc).isoformat(timespec="seconds"), i) for i in ids])
                    db.commit()
                    return self.send_json({"updated":len(ids)})
                if self.path == "/api/settings":
                    box = payload
                    for field in ("industries", "locations"):
                        if not isinstance(box.get(field, []), list) or len(box.get(field, [])) > 30 or any(not isinstance(v, str) or len(v) > 80 for v in box.get(field, [])):
                            return self.send_json({"error":f"{field} must be a list of up to 30 short strings."}, 400)
                    box["revenue_min"] = float(box["revenue_min"]) if box.get("revenue_min") not in (None, "") else None
                    box["revenue_max"] = float(box["revenue_max"]) if box.get("revenue_max") not in (None, "") else None
                    box["employee_min"] = int(box["employee_min"]) if box.get("employee_min") not in (None, "") else None
                    box["employee_max"] = int(box["employee_max"]) if box.get("employee_max") not in (None, "") else None
                    for field in ("revenue_min", "revenue_max", "employee_min", "employee_max"):
                        val = box[field]
                        if val is not None and (not math.isfinite(val) or val < 0):
                            return self.send_json({"error":f"{field} must be a non-negative finite number."}, 400)
                    if box["revenue_min"] is not None and box["revenue_max"] is not None and box["revenue_min"] > box["revenue_max"]: return self.send_json({"error":"Revenue minimum cannot exceed maximum."}, 400)
                    if box["employee_min"] is not None and box["employee_max"] is not None and box["employee_min"] > box["employee_max"]: return self.send_json({"error":"Employee minimum cannot exceed maximum."}, 400)
                    db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('buybox',?)", (json.dumps(box),))
                    db.commit()
                    return self.send_json(box)
        except sqlite3.OperationalError as exc:
            locked = "locked" in str(exc).lower() or "busy" in str(exc).lower()
            return self.send_json({"error":"The database is busy; retry the request." if locked else "Database operation failed."}, 503 if locked else 500)
        except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
            return self.send_json({"error": str(exc)}, 400)
        self.send_json({"error":"Not found"}, 404)


def run(host="127.0.0.1", port=8000):
    init_db()
    server = ThreadingHTTPServer((host, port), Handler)
    print(f"LeadBench running at http://{host}:{port}")
    try: server.serve_forever()
    except KeyboardInterrupt: print("\nStopping LeadBench")
    finally: server.server_close()


if __name__ == "__main__":
    run(os.environ.get("HOST", "127.0.0.1"), int(os.environ.get("PORT", "8765")))
