$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$serverPath = Join-Path $projectRoot 'server.py'
$pythonCommand = $null
$usePythonLauncher = $false

function Test-LeadBenchPython {
    param([string]$CandidatePath, [bool]$IsLauncher = $false)
    if ($CandidatePath -match '\\WindowsApps\\') { return $false }
    try {
        $versionArgs = @('--version')
        if ($IsLauncher) { $versionArgs = @('-3','--version') }
        $versionText = (& $CandidatePath @versionArgs 2>$null) -join ' '
        if ($LASTEXITCODE -ne 0 -or $versionText -notmatch 'Python\s+(\d+)\.(\d+)') { return $false }
        return ([int]$Matches[1] -gt 3 -or ([int]$Matches[1] -eq 3 -and [int]$Matches[2] -ge 10))
    } catch { return $false }
}

if ($env:LEADBENCH_PYTHON) {
    if (-not (Test-Path -LiteralPath $env:LEADBENCH_PYTHON -PathType Leaf) -or -not (Test-LeadBenchPython $env:LEADBENCH_PYTHON)) {
        throw 'LEADBENCH_PYTHON must point to a working Python 3.10 or later executable.'
    }
    $pythonCommand = $env:LEADBENCH_PYTHON
}
if (-not $pythonCommand) {
    foreach ($name in @('python3','python','py')) {
        $candidate = Get-Command $name -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($candidate -and (Test-LeadBenchPython $candidate.Source ($name -eq 'py'))) {
            $pythonCommand = $candidate.Source
            $usePythonLauncher = $name -eq 'py'
            break
        }
    }
}
if (-not $pythonCommand) {
    $userProfilePath = [Environment]::GetFolderPath('UserProfile')
    $bundledPython = Join-Path $userProfilePath '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
    if ((Test-Path -LiteralPath $bundledPython -PathType Leaf) -and (Test-LeadBenchPython $bundledPython)) { $pythonCommand = $bundledPython }
}
if (-not $pythonCommand) { throw 'Python 3.10 or later was not found. Install it or set LEADBENCH_PYTHON to its executable.' }
if (-not $env:HOST) { $env:HOST = '127.0.0.1' }
if (-not $env:PORT) { $env:PORT = '8765' }
if (-not $env:LEAD_DB_PATH) { $env:LEAD_DB_PATH = Join-Path $projectRoot 'data\leads.sqlite3' }
Write-Host "Starting LeadBench at http://$($env:HOST):$($env:PORT)"
Write-Host "Python: $pythonCommand"
if ($usePythonLauncher) { & $pythonCommand -3 $serverPath } else { & $pythonCommand $serverPath }
if ($LASTEXITCODE -ne 0) { throw "LeadBench stopped with exit code $LASTEXITCODE." }
